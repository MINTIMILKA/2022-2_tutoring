package Array_project;

import java.util.Arrays;

public class array_main {

	public static void main(String[] args) 
	{
		//테스트를 위한 배열 
		//null과 {}를 구분해야함 
		int[] null_array = null;
		int[] test_array = {2, 4, 6, 8, 10};
		int[][] test_array_2 = {{2, 4, 6}, {3, 6, 9}, {7, 14, 21, 28}, {}};
		int[][][] test_array_3 = {{{9, 8}, {1, 10, 100} ,{3, 9, 27}}, {{6, 36, 216}, {1, 11, 111}}, {{543}}};
		int[][][][] test_array_4 = {{{{9, 8}, {1, 10, 100} ,{3, 9, 27}}, 
									{{6, 36, 216}, {1, 11, 111}}, {{543}}}, 
									{{{11, 22, 33, 44}, {55, 66, 77}}, 
									{{1212, 2323, 3434}, {1919, 2828, 3737, 4646}, {0, 5, 10, 15, 20}}}};
		
		//원래의 toString 연산
		System.out.println("Arrays.toString: " + Arrays.toString(test_array));
		
		//직접 제작한 toString 연산 
		System.out.println("MyArrays.toString: " + MyArrays.toString(test_array));
		
		//원래의 deepToString 연산
		System.out.println("Arrays.deepToString:   " + Arrays.deepToString(test_array_3));
		
		//직접 제작한 deepToString 연산 
		System.out.println("MyArrays.deepToString: " + MyArrays.deepToString(test_array_3));
		
	}
}


