package Array_project;

import java.lang.Number;

public class MyArrays 
{
	static String toString(int[] a)
	{
		//System.out.println("to: " + a);
		String result = "";
		
		if(a instanceof int[])
		{
			result += "[";
			
			if(a.length > 0)
			{
				result += a[0];
			}
			
			for(int i=1;i<a.length;i++)
			{
				result += ", "+a[i];
			}
			
			result += "]";
			
			return result;
		}
		else
		{
			return "null";
		}
	}
	
	static String deepToString(Object[] a)
	{
		String result = "[";
		
		result = array_function(result, a);
		
		result += "]";
		
		return result;
	}
	
	static private String array_function(String result, Object[] a)
	{
		//object[]는 int[][]를 포함함 
		//object는 int[]와 int[][]를 모두 포함함 
		if(a.getClass().isArray())
		{
			if(a instanceof Object[][])
			{
				for(int i=0;i<a.length;i++)
				{
					if(i>0)
					{
						result += ", ";
					}
					
					Object[] sub_a = array_function_2(a, i);
					
					result += "[";
					result = array_function(result, sub_a);
					result += "]";
				}
			}
			else //int[][]가 남음 
			{
				for(int j=0;j<((int[][])a).length;j++)
				{
					if(j>0)
					{
						result += ", ";
					}
					
					result += "[";
					
					for(int k=0;k<((int[])(a[j])).length;k++)
					{
						if(k>0)
						{
							result += ", ";
						}
						result += (((int[])(a[j]))[k]);
					}
					result += "]";
				}
			}
		}
		return result;
	}
	
	static private Object[] array_function_2(Object[] a, int b)
	{
		return (Object[])a[b];
	}
}
