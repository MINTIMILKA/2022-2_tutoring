package JAVA_2_class_car_example;

public class test_drive {

	public static void main(String[] args)
	{
		//자동차 예제 
		//영혼까지 끌어모아 4인승 차 한대를 마련한다. 
		test_car_class car_A = new test_car_class(4);
		
		int traveler = 3;
		
		//자동차에 3명 탑승  
		if(car_A.board_car(traveler) > 0)
		{
			System.out.println("\n[system]: 운전 준비 완료 \n");
		}
		else
		{
			System.out.println("\n[system]: 탑승 못함 \n");
		}
		
		//자동차 출발 
		System.out.println("========================");
		car_A.drive_car();
		System.out.println("========================\n");
		
		//도착후 3명 하차 
		if(car_A.get_off_car(2) <= 0)
		{
			System.out.println("\n[system]: 모두 차에 내린것을 확인함 \n");
		}
		else
		{
			System.out.println("\n[system]: 아칙 차에 남아있는 인원을 확인함 \n");
		}
		
		//버스 예제 
		System.out.println("\n + 버스 예제\n");
		
		//30인승 버스 운전기사로 취직한다. 
		bus bus_B = new bus(30);
		
		bus_B.board_car(7);
		bus_B.print_bus_status();
		bus_B.drive_car();
		bus_B.board_car(10);
		bus_B.print_bus_status();
		bus_B.drive_car();
		bus_B.get_off_car(17);
		bus_B.print_bus_status();
		bus_B.drive_car();
	}

}
