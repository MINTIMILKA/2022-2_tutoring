package JAVA_2_class_car_example;

//상속 예제 
public class bus extends test_car_class
{
	//버스 요금 
	int bus_fee;
	
	//버스 초기화 (MAX_SEATER: 최대 탑승 가능 인원, bus_fee: 버스 요금) 
	bus(int MAX_SEATER, int bus_fee)
	{
		super(MAX_SEATER);
		
		this.bus_fee = bus_fee;
	}
	bus(int MAX_SEATER)
	{
		//기본요금 1000원인 버스를 초기화 
		this(MAX_SEATER, 1000);
	}
	
	//버스 상태 확인 
	public void print_bus_status()
	{
		System.out.println("======== 버스 상황 ========");
		System.out.println("버스 요금: " + bus_fee + "원");
		System.out.println("현재 승객 수: " + seater_num + "/" + MAX_SEATER);
		System.out.println("버스 바퀴 수: " + TIRE_NUM);
		System.out.println("========================\n");
	}
	
	//오버라이드  
	//버스 운전 
	@Override
	public void drive_car()
	{
		if((seater_num > 0) && (seater_num <= MAX_SEATER))
		{
			System.out.println("<< 버스가 달립니다~ >>");
		}
		else if(seater_num <= 0)
		{
			System.out.println("<< 사람이 없어도 버스는 계속 운행합니다~ >>");
		}
		else if(seater_num > MAX_SEATER)
		{
			System.out.println("<< 버스가 너무 무겁습니다! >>");
		}
		
		System.out.println();
	}
}
