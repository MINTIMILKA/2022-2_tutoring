package JAVA_2_class_car_example;

public class test_car_class 
{	
	//현재 자동차에 탑승한 사람의 수
	int seater_num = 0;
	
	//최대 탑승 가능 인원 (2인승, 4인승...)(final 이므로 생성자를 이용해서 꼭 초기화 해야함) 
	//final: 상수 변수 선언 
	final int MAX_SEATER;
	
	//바퀴 수 
	final int TIRE_NUM;
	
	//생성자를 이용하여 클래스 초기화 
	test_car_class(int MAX_SEATER)
	{
		this.MAX_SEATER = MAX_SEATER;
		this.TIRE_NUM = 4;
	}
	//생성자 오버로드 
	test_car_class(int TIRE_NUM, int MAX_SEATER)
	{
		this.MAX_SEATER = MAX_SEATER;
		this.TIRE_NUM = TIRE_NUM;
	}
	
	//탑승 (person_num: 탑승 인원 수)
	public int board_car(int person_num)
	{
		if((seater_num + person_num) <= MAX_SEATER)
		{
			seater_num = seater_num + person_num;
			System.out.println(person_num + "명 탑승하여 " + seater_num + "명이 자동차 안에 있습니다. ");
		}
		else
		{
			System.out.println("탑승할 인원의 수가 너무 많습니다. ");
		}
		//현재 탑승된 인원 수 반환 
		return seater_num;
	}
	
	//하차 (person_num: 탑승 인원 수)
	public int get_off_car(int person_num)
	{
		//현재 인원이 0명일 경우(음수일 때는 0으로 초기화)
		if(seater_num <= 0)
		{
			seater_num = 0;
			System.out.println("하차할 인원이 없습니다. ");
			
			return 0;
		}
		else //탑승 인원이 한명이라도 존재할 경우 
		{
			if((seater_num - person_num) >= 0)
			{
				seater_num = seater_num - person_num;
				System.out.println(person_num + "명 하차하여 " + seater_num + "명 남았습니다. ");
			}
			else
			{
				seater_num = 0;
				System.out.println(seater_num + "명을 초과하여 하차할 수 없기 때문에 모두 하차하였습니다. ");
			}
			
			//현재 탑승된 인원 수 반환 
			return seater_num;
		}
	}
	
	//운전 
	public void drive_car()
	{
		if((seater_num > 0) && (seater_num <= MAX_SEATER))
		{
			System.out.println("자동차가 달립니다~");
		}
		else if(seater_num <= 0)
		{
			System.out.println("운전할 사람이 부족합니다! ");
		}
		else if(seater_num > MAX_SEATER)
		{
			System.out.println("자동차가 너무 무겁습니다! ");
		}
	}
}
