package JAVA_1_print_test;

public class test_class {

	public static void main(String[] args) 
	{
		//1. 덧셈이 가능한 자바의 문자열 출력(println, print) 
		System.out.println("<<마지막에 자동으로 " + "엔터가(줄바꿈이) 되는 " + "단순한 문자열>>");
		System.out.print("ln이 없어서 자동 줄바꿈이 안됨");
		System.out.print("\n\n");
		
		//2. C언어 문자열 출력(printf) (문자열 덧셈 불가능)
		String a = "선정된 번호는";
		int b = 83;
		
		System.out.printf("%s %d입니다. \n\n", a, b);
		
		//3. if else문
		int plus_result = 2+1;
		
		if(plus_result > 5)
		{
			System.out.println("plus_result의 값 " + plus_result + "는 5보다 큽니다.");
		}
		else if((plus_result > 0) && (plus_result < 5))
		{
			System.out.println("plus_result의 값이 5보다 작습니다. (값: " + plus_result + ")");
		}
		System.out.println();
		
		//4. switch_case문
		String string_value = "빨간색";
		
		switch(string_value)
		{
			case "빨간색": 
				System.out.println("빨간색은 영어로 레드");
				break;
			case "노랑색":
				System.out.println("노란색은 영어로 옐로우");
				break;
			case "초록색":
				System.out.println("초록색은 영어로 그린");
				break;
			default:
				System.out.println("미쿡말 몰라요");
		}
		System.out.println();
		
		//5. C언어 for문, while문 
		int[] num_array = new int[10]; //자바 배열 선언 
		int temp; //임시 저장 변수 
		
		num_array[0]=8; num_array[1]=3; num_array[2]=9; num_array[3]=2; num_array[4]=6;
		num_array[5]=1; num_array[6]=4; num_array[7]=0; num_array[8]=5; num_array[9]=7;
		
		System.out.print("처음 순서  ");
		for(int h=0;h<num_array.length;h++)
			System.out.print(" -> " + num_array[h]);
		System.out.println();
		
		for(int i=0;i<num_array.length;i++)
		{
			for(int j=i+1;j<num_array.length;j++)
			{
				if(num_array[i]>num_array[j])
				{
					temp = num_array[i];
					num_array[i] = num_array[j];
					num_array[j] = temp;
				}
			}
		}
		
		temp = 0;
		
		System.out.print("정렬된 순서 ");
		while(temp < num_array.length)
		{
			System.out.print(" -> " + num_array[temp]);
			
			temp++;
		}
		System.out.println();
		
		//6. java에서 추가된 for문 
		System.out.print("다시 출력하기");
		for(int num_a : num_array)
		{
			System.out.print(" -> " + num_a);
		}
		System.out.println();
		
	}
}
