package JAVA_3_abstract_class_example;

public class small_car extends prototype_car 
{
	//생성자 정의 부모(prototype_car)의 생성자로 초기화 
	small_car()
	{
		//4인승, 바퀴 4개로 초기화
		super(4);
	}
	
	//[추상 메소드] 탑승 (person_num: 탑승 인원 수)
	public int board_car(int person_num)
	{
		return 0;
	}
	
	//[추상 메소드] 하차 (person_num: 탑승 인원 수)
	public int get_off_car(int person_num)
	{
		return 0;
	}
	
	//[추상 메소드] 시동(키(비밀번호)를 입력하여 시동함)
	public boolean operate_car(int key)
	{
		return false;
	}
	
	//[추상 메소드] 운전(is_ready: 시동이 켜졌을 때 true)
	public void drive_car(boolean is_ready)
	{
		//
	}
}
