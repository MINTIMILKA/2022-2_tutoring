package JAVA_3_abstract_class_example;

//자동차 프로토타입(원형)을 추상 클래스로 정의함 
public abstract class prototype_car 
{
	//현재 자동차에 탑승한 사람의 수
	int seater_num = 0;
	
	//최대 탑승 가능 인원 (2인승, 4인승...)(final 이므로 생성자를 이용해서 꼭 초기화 해야함) 
	//final: 상수 변수 선언 
	final int MAX_SEATER;
	
	//바퀴 수 
	final int TIRE_NUM;
	
	//추상 메소드에서 생성자 정의 가능 
	prototype_car(int MAX_SEATER)
	{
		this.MAX_SEATER = MAX_SEATER;
		this.TIRE_NUM = 4;
	}
	//생성자 오버로드 
	prototype_car(int TIRE_NUM, int MAX_SEATER)
	{
		this.MAX_SEATER = MAX_SEATER;
		this.TIRE_NUM = TIRE_NUM;
	}
	
	//[추상 메소드] 탑승(person_num: 탑승 인원 수)
	public abstract int board_car(int person_num);
	
	//[추상 메소드] 하차(person_num: 탑승 인원 수)
	public abstract int get_off_car(int person_num);
	
	//[추상 메소드] 시동(키(비밀번호)를 입력하여 시동함)
	public abstract boolean operate_car(int key);
	
	//[추상 메소드] 운전(is_ready: 시동이 켜졌을 때 true)
	public abstract void drive_car(boolean is_ready);
	
}
